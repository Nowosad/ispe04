#' 
#' Run the code below:
#' 
## ---- message=FALSE---------------------
library(sf)
library(tmap)
library(spData)
library(dplyr)
us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))

#' 
#' 1. Create a map of the contiguous United States, where labels represent states' names, and their size depends on the states' areas.
#' 2. Create a line map using the `seine` object. 
#' Try to use a dark color for a background. 
#' What are the pros and cons of using dark backgrounds?
#' 3. Improve the map of the urban agglomerations in 2020 further by adding a map title, graticules, scale bar, north arrow, and text annotation.
#' 4. Additional: try different layout styles on the result from Exercise 3.
