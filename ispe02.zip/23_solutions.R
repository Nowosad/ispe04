#' 
#' Run the code below:
#' 
## ---- message=FALSE---------------------
library(sf)
library(tmap)
library(spData)
library(dplyr)
us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))

#' 
#' 1. Create a map of the contiguous United States, where labels represent states' names, and their size depends on the states' areas.
#' 
## ---------------------------------------
tm_shape(us_states) +
  tm_polygons() +
  tm_text("NAME", size = "AREA")

#' 
#' 2. Create a line map using the `seine` object. 
#' Try to use a dark color for a background. 
#' What are the pros and cons of using dark backgrounds?
#' 
## ---------------------------------------
tm_shape(seine) +
  tm_lines()

tm_shape(seine) +
  tm_lines() +
  tm_layout(bg.color = "darkgray")

tm_shape(seine) +
  tm_lines(col = "blue") +
  tm_layout(bg.color = "darkgray")

#' 
#' 3. Improve the map of the urban agglomerations in 2020 further by adding a map title, graticules, scale bar, north arrow, and text annotation.
#' 
## ---------------------------------------
urb_2020 =  subset(urban_agglomerations, year == 2020)
tm_shape(world) +
  tm_polygons() +
  tm_shape(urb_2020) +
  tm_symbols("population_millions") +
  tm_layout(title = "Map title") +
  tm_graticules() +
  tm_scale_bar() +
  tm_compass() +
  tm_credits("Text annotation")

#' 
#' 4. Additional: try different layout styles on the result from Exercise 3.
#' 
## ---------------------------------------
tm_shape(world) +
  tm_polygons() +
  tm_shape(urb_2020) +
  tm_symbols("population_millions") +
  tm_layout(title = "Map title") +
  tm_graticules() +
  tm_scale_bar() +
  tm_compass() +
  tm_credits("Text annotation") +
  tm_style("classic")

#' 
