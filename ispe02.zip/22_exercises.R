#' 1. Load the `rivers` dataset from the **tmap** package using `data("rivers", package = "tmap")`.
#' Create a rivers' map where the line width derives from the `strokelwd` variable.
#' 2. Test `tm_squares()`, `tm_bubbles()`, `tm_dots()`, and `tm_markers()` instead of `tm_symbols()` for the map of the urban agglomnerations in 2020.
#' How are they different from each other?
#' 3. Improve the map of the urban agglomerations in 2020 by adding world' countries borders from the `world` object and changing the legend title.
#' Each symbol size should represent the city population.
#' 4. Improve the elevation map of the New Zealand area by classifying values into four groups: (1) "Depressions" (below 0), "Plains" (between 0 and 300), "Hills" (between 300 and 600), "Mountains" (above 600).
#' 5. Additional: try repeating the steps from the article [Geocomputation with R: maps extended](https://geocompr.github.io/geocompkg/articles/maps.html) in order to make a hillshade map of a country of your choice.
