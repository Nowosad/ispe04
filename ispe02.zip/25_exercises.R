#' 
#' 1. Create a map of life expectancy using `world` with facets representing different subregions.
#' 2. Think of how you can improve the map style of the `urb_anim` object.
#' Try to implement your ideas.
#' Save the results as a new file.
