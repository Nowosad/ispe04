library(sf)
library(tmap)
library(spData)
tm_shape(nz) +
  tm_polygons()

tmap_mode("view")
tm_shape(nz) +
  tm_polygons()

tmap_mode("plot")
tm_shape(nz) +
  tm_polygons()

library(leaflet)
tmap_mode("view")
tm_shape(nz) +
  tm_polygons() + 
  tm_basemap(server = "OpenTopoMap") +
  tm_minimap()

mapview::mapview(nz) + nz_height

library(maptiles)
library(tmap)
tmap_mode("plot")
nz_tiles = get_tiles(nz, crop = TRUE,
                     zoom = 6, provider = "Stamen.Toner")

tm_shape(nz_tiles) + tm_rgb() + 
  tm_shape(nz) + tm_borders(lwd = 5, col = "red") +
  tm_credits(get_credit("Stamen.Toner"), position = c("RIGHT", "BOTTOM"))

tm1 = tm_shape(nz) +
  tm_polygons()
tm1

tmap_save(tm1,
          filename = "my_map.png",
          width = 6,
          height = 6,
          asp = 0)

tmap_save(tm1,
          filename = "my_map2.png",
          width = 6,
          height = 6,
          asp = 0,
          scale = 0.5)

tmap_save(tm1, 
          filename = "my_map.html")

tmap_save(tm1, 
          filename = "my_map.pdf")
