## ---------------------------------------
library(tmap)
library(sf)

#' 
#' 1. Load the `rivers` dataset from the **tmap** package using `data("rivers", package = "tmap")`.
#' Create a rivers' map where the line width derives from the `strokelwd` variable.
#' 
## ---------------------------------------
data("rivers", package = "tmap")
tm_shape(rivers) +
  tm_lines("strokelwd")

#' 
#' 2. Test `tm_squares()`, `tm_bubbles()`, `tm_dots()`, and `tm_markers()` instead of `tm_symbols()` for the map of the urban agglomnerations in 2020.
#' How are they different from each other?
#' 
## ---------------------------------------
library(spData)
urb_2020 =  subset(urban_agglomerations, year == 2020)
tm_shape(urb_2020) + tm_symbols()
tm_shape(urb_2020) + tm_squares()
tm_shape(urb_2020) + tm_bubbles()
tm_shape(urb_2020) + tm_dots()
tm_shape(urb_2020) + tm_markers()

#' 
#' 3. Improve the map of the urban agglomerations in 2020 by adding world' countries borders from the `world` object and changing the legend title.
#' Each symbol size should represent the city population.
#' 
## ---------------------------------------
tm_shape(world) +
  tm_polygons() +
  tm_shape(urb_2020) +
  tm_symbols("population_millions")

#' 
#' 4. Improve the elevation map of the New Zealand area by classifying values into four groups: (1) "Depressions" (below 0), "Plains" (between 0 and 300), "Hills" (between 300 and 600), "Mountains" (above 600).
#' 
## ---------------------------------------
library(spDataLarge)
library(terra)
data("nz_elev", package = "spDataLarge")
nz_elev = rast(nz_elev)
tm_shape(nz_elev) +
  tm_raster(breaks = c(-99, 0, 300, 600, 9999),
            labels = c("Depressions", "Plains", "Hills", "Mountains"),
            palette = "-RdYlGn",
            midpoint = 0)

#' 
#' 5. Additional: try repeating the steps from the article [Geocomputation with R: maps extended](https://geocompr.github.io/geocompkg/articles/maps.html) in order to make a hillshade map of a country of your choice.
