library(sf)
library(terra)
library(tmap)
library(dplyr)
library(spData)
library(spDataLarge)

tm_shape(seine) +
  tm_lines(lwd = 3, lty = 2)

seine

tm_shape(seine) +
  tm_lines(col = "name")

tm_shape(seine) +
  tm_lines(col = "name",
           palette = "Set1")

urb_2020 =  subset(urban_agglomerations, year == 2020)

tm_shape(urb_2020) +
  tm_symbols(col = "black",
             size = "population_millions",
             shape = 19)

tm_shape(urb_2020) +
  tm_symbols(col = "population_millions",
             size = 1,
             shape = 19)

tm_shape(urb_2020) +
  tm_symbols(col = "population_millions",
             size = 1,
             shape = 19)

nz_elev = rast(nz_elev)

tm_shape(nz_elev) +
  tm_raster()

tm_shape(nz_elev) +
  tm_raster(palette = "Greens",
            style = "cont")

tm_shape(nz_elev) +
  tm_raster(palette = "Greens",
            style = "cont",
            title = "Elevation (m a.s.l)") +
  tm_shape(nz) + 
  tm_borders()

tm_shape(world) +
  tm_polygons(col = "#e6e6e6") +
  tm_shape(urb_2020) +
  tm_symbols(col = "#c15b5b")
