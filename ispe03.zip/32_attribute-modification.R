library(sf)
library(dplyr)
library(spData)

world = select(world, name_long, continent, region_un, pop, area_km2)
# glimpse(world)
world 

world2 = rename(world, name = name_long)
world2

world3 = mutate(world, pop_dens = pop / area_km2)
world3

world4 = mutate(world, name_long = if_else(name_long == "Côte d'Ivoire",
                                           "Ivory Coast", #true
                                           name_long)) #false
world4

world_df = st_drop_geometry(world)
class(world_df)

summary(world)

library(terra)
library(spData)
library(spDataLarge)
elevation = rast(system.file("raster/srtm.tif", package = "spDataLarge"))

values(elevation)



plot(elevation)

emask = elevation > 2000
plot(emask)

elevation2 = selectRange(elevation, emask)
plot(elevation2)

elevation3 = elevation2
elevation3[is.na(elevation3)] = 2000
plot(elevation3)

global(elevation, sd)
global(elevation, mean)
summary(elevation) # the size argument is important

nlcd = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
plot(nlcd)

freq(nlcd)


nz_elev = rast(nz_elev)
nlcd = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
