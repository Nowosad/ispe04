#' 1. Create a new data frame `seine_df` with two columns and three rows: the first column `Discharge` should contain values `75`, `21`, `66`; the second column `Type` should store `"T"`, `"T"`, `"M"`.
#' Combine the `seine` object with this new data frame.
#' Vizualize the results.
#' 
## ----------------------------------------------------------------------
library(spData)
library(sf)
library(dplyr)

seine_df = data.frame(Discharge = c(75, 21, 66),
                      Type = c("T", "T", "M"))

seine_df
seine

seine2 = bind_cols(seine, seine_df)
seine2 = st_as_sf(seine2)

library(tmap)
tm_shape(seine2) + tm_lines("Discharge", palette = "Blues") +
  tm_layout(bg.color = "darkgray")

#' 
#' 2. `us_states` has 49 observations, while `us_states_df` has 51 observations. 
#' How can you find out which are the different features between those two objects?
#' 
## ----------------------------------------------------------------------
us_states
us_states_df

?join

anti_join(us_states, us_states_df, by = c("NAME" = "state"))
anti_join(us_states_df, us_states, by = c("state" = "NAME"))

setdiff(us_states$NAME, us_states_df$state)
setdiff(us_states_df$state, us_states$NAME)

#' 
#' 3. Join `us_states` with the `us_states_df` object.
#' 
## ----------------------------------------------------------------------
us_states
us_states_df

us_states2 = left_join(us_states, us_states_df,
                       by = c("NAME" = "state"))
tm_shape(us_states2) + 
  tm_polygons(col = "poverty_level_15") +
  tm_layout(legend.outside = TRUE)

#' 
#' 4. Use the result of the previous exercise to create a facet map representing the median income for the years 2010 and 2015.
#' (Hist: use `pivot_longer()`.)
#' <!-- 4. Rows binding -->
#' 
## ----------------------------------------------------------------------
tm1 = tm_shape(us_states2) +
  tm_polygons("median_income_10",
              breaks = c(20000, 35000, 50000))
tm2 = tm_shape(us_states2) +
  tm_polygons("median_income_15",
              breaks = c(20000, 35000, 50000))
tmap_arrange(tm1, tm2, ncol = 1)

us_states2
library(tidyr)
us_states3 = pivot_longer(us_states2, 
                    key = "year", value = "mi",
                    median_income_10:median_income_15)
us_states3 = st_as_sf(us_states3)

tm_shape(us_states3) +
  tm_polygons("mi") +
  tm_facets("year")

#' 
