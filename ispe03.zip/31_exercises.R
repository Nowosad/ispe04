#' 
## ----------------------------------------------------------------------
nz_elev = rast(nz_elev)

#' 
#' 1. Select only the `name_long`, `continent`, and `pop` variables from the `world` object. 
#' Try different techniques to achieve this result.
#' 2. Find all countries with the following characteristics:
#'     - Are in Africa.
#'     - Have a population greater than 35 mln.
#'     - Are in Africa and have a population greater than 35 mln.
#' 3. Plot the `nz_elev` object.
#' Select only cells with elevation below 1500 or above 2500 m a.s.l.
#' 4. Additional: plot the results of Exercise 2.
