#' 1. Create a new data frame `seine_df` with two columns and three rows: the first column `Discharge` should contain values `75`, `21`, `66`; the second column `Type` should store `"T"`, `"T"`, `"M"`.
#' Combine the `seine` object with this new data frame.
#' Vizualize the results.
#' 2. `us_states` has 49 observations, while `us_states_df` has 51 observations. 
#' How can you find out which are the different features between those two objects?
#' 3. Join `us_states` with the `us_states_df` object.
#' 4. Use the result of the previous exercise to create a facet map representing the median income for the years 2010 and 2015.
#' (Hist: use `pivot_longer()`.)
#' <!-- 4. Rows binding -->
