#' 
#' 1. Select only the `name_long`, `continent`, and `pop` variables from the `world` object. 
#' Try different techniques to achieve this result.
#' 
## ----------------------------------------------------------------------
library(dplyr)
library(spData)
library(sf)

world1 = dplyr::select(world, name_long, continent, pop)
world1

world2 = world[c("name_long", "continent", "pop")]
world2

#' 
#' 2. Find all countries with the following characteristics:
#'     - Are in Africa.
#'     - Have a population greater than 35 mln.
#'     - Are in Africa and have a population greater than 35 mln.
#'     
## ----------------------------------------------------------------------
ex2_a = world %>% 
  filter(continent == "Africa")

ex2_b = world %>% 
  filter(pop > 35000000)

ex2_c = world %>% 
  filter(continent == "Africa",
         pop > 35000000)

#'     
#' 3. Plot the `nz_elev` object.
#' Select only cells with elevation below 1500 or above 2500 m a.s.l.
#' 
## ----------------------------------------------------------------------
library(tmap)
library(terra)
tm_shape(nz_elev) +
  tm_raster()

ex3_sel = nz_elev > 2500 | nz_elev < 1500
ex3 = selectRange(nz_elev, ex3_sel)
plot(ex3)

#' 
#' 4. Additional: plot the results of Exercise 2.
#' 

#' 
