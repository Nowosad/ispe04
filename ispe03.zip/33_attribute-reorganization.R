library(sf)
library(dplyr)
library(spData)

n_amer = world %>%
  filter(subregion == "Northern America") %>%
  dplyr::select(iso_a2, name_long)
n_amer

n_amer_db1 = data.frame(forest_area = c(4916438, 3100950, 2))
n_amer_db1

n_amer

# remotes::install_github("tidyverse/dplyr")
library(dplyr)
bind_cols(n_amer,
          n_amer_db1)

cbind(n_amer,
      n_amer_db1)

st_bind_cols(n_amer,
             n_amer_db1)

n_amer_wb = worldbank_df %>% 
  filter(name %in% c("Canada", "Mexico", "United States")) %>%
  dplyr::select(name, iso_a2, urban_pop, unemploy = unemployment)
n_amer_wb

n_amer

left_join1 = n_amer %>% 
  left_join(n_amer_wb, by = "iso_a2")
left_join1

plot(n_amer)

plot(left_join1)

left_join2 = n_amer %>% 
  left_join(n_amer_wb, by = c("name_long" = "name"))
left_join2

left_join3 = n_amer %>% 
  left_join(n_amer_wb, by = c("iso_a2", "name_long" = "name"))
left_join3

left_join4 = n_amer_wb %>%
  left_join(n_amer, by = c("iso_a2"))
left_join4

inner_join1 = n_amer %>% 
  inner_join(n_amer_wb, by = c("iso_a2", "name_long" = "name"))
inner_join1

n_amer_db2 = data.frame(Canada = 4916438, UnitedStates = 3100950, Greenland = 2)
n_amer_db2

n_amer

library(tidyr)
n_amer_db2_long = pivot_longer(n_amer_db2, 
                               names_to = "name_long", 
                               values_to = "forest_area", 
                               Canada:Greenland)
n_amer_db2_long

n_amer_db2_long = n_amer_db2_long %>% 
  mutate(name_long = if_else(name_long == "UnitedStates", "United States", name_long))
n_amer_db2_long

left_join5 = n_amer %>% 
  left_join(n_amer_db2_long, by = "name_long")
left_join5

c_amer = world %>%
  filter(subregion == "Central America") %>%
  dplyr::select(iso_a2, name_long)
c_amer

nc_amer = rbind(n_amer, c_amer)
nc_amer

plot(st_geometry(n_amer))

plot(st_geometry(nc_amer))
