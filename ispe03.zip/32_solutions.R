#' 1. Create a new object, `world_pop_dens`, and add a new column `pop_dens` with a population density for each country.
#' 
## ----------------------------------------------------------------------
library(sf)
library(spData)
library(dplyr)
world_pop_dens = world %>% 
  mutate(pop_dens = pop/area_km2)
world_pop_dens

# world_pop_dens %>% 
#   arrange(-pop_dens) %>% 
#   slice(1:5) %>% 
#   dplyr::select(name_long, pop_dens)

#' 
#' 2. Calculate a maximum, minimum, and average elevation in the `nz_elev` dataset.
#' 
## ----------------------------------------------------------------------
library(spDataLarge)
nz_elev = rast(nz_elev)

global(nz_elev, min)
global(nz_elev, max)
global(nz_elev, mean)

#' 
#' 3. Replace the values between 2000 and 3000 in the `nz_elev` dataset with a value of `NA`. 
#' Calculate a maximum, minimum, and average elevation in the newly created object.
#' 
## ----------------------------------------------------------------------
nz_mask = nz_elev > 2000 & nz_elev < 3000
nz_elev2 = selectRange(nz_elev, nz_mask)

global(nz_elev2, "min", na.rm = TRUE)
global(nz_elev2, "max", na.rm = TRUE)
global(nz_elev2, "mean", na.rm = TRUE)

#' 
#' 4. Replace the values of 11 with a value of 1 in the `nlcd` dataset.
#' 
## ----------------------------------------------------------------------
nlcd = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))

plot(nlcd)

nlcd[nlcd == 11] = 1
plot(nlcd)

