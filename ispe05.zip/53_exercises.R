#' 
#' 1. Extract elevation values in a 500 meters buffer around each point in `zion_points`.
#' Calculate the average value for each point. 
#' Extract elevation values for each point in `zion_points`.
#' Compare these two results.
#' 2. Extract elevation values for each region in `nz` from `nz_elev`. 
#' Which region has the lowest and largest average elevation value?
#' Which region has the lowest and largest diversity of elevation values?
