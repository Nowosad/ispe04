library(sf)
library(terra)
library(spData)
library(spDataLarge)
nz
data("nz_elev", package = "spDataLarge")
nz_elev = rast(nz_elev)
otago = subset(nz, Name == "Otago")



nz_elev_cropped = crop(nz_elev, vect(otago))



nz_elev_masked = mask(nz_elev, vect(otago))



nz_elev_cropped = crop(nz_elev, vect(otago))
nz_elev_masked2 = mask(nz_elev_cropped, vect(otago))




srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm2 = aggregate(srtm, fact = 4)
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))
zion = st_transform(zion, crs(srtm2))
