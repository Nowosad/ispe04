#' 
#' 1. Extract elevation values in a 500 meters buffer around each point in `zion_points`.
#' Calculate the average value for each point. 
#' Extract elevation values for each point in `zion_points`.
#' Compare these two results.
#' 
## ----------------------------------------------------------------------
library(sf)
library(terra)
library(spData)
library(spDataLarge)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm2 = project(srtm, nlcd)

zion_points2 = st_transform(zion_points, crs = st_crs(srtm2))
zion_points_500 = st_buffer(zion_points2, 500)

multi_vals = extract(srtm2, vect(zion_points_500)) %>% 
  group_by(ID) %>% 
  summarise(mean = mean(srtm))

single_vals = extract(srtm2, vect(zion_points2))

plot(multi_vals$mean, single_vals$srtm)

#' 
#' 2. Extract elevation values for each region in `nz` from `nz_elev`. 
#' Which region has the lowest and largest average elevation value?
#' Which region has the lowest and largest diversity of elevation values?
#' 
## ----------------------------------------------------------------------
library(sf)
library(tmap)
data("nz_elev", package = "spDataLarge")
nz_elev = rast(nz_elev)
tm_shape(nz_elev) +
  tm_raster(style = "cont") +
  tm_shape(nz) + 
  tm_borders(lwd = 3)

nz_extr = terra::extract(nz_elev, vect(nz))
head(nz_extr)
summary(nz_extr)

nz_extr_df = nz_extr %>% 
  group_by(ID) %>% 
  summarize(avg = mean(elevation, na.rm = TRUE))

nz = bind_cols(nz, nz_extr_df)
nz %>% 
  arrange(avg) %>% 
  slice(1) %>% 
  pull(Name)

nz %>% 
  arrange(-avg) %>% 
  slice(1) %>% 
  pull(Name)

