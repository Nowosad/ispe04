#' 1. Select the elevation data for the Northland and Auckland regions only.
#' Visualize the results.
#' 
## ----------------------------------------------------------------------
library(sf)
library(dplyr)
library(spData)

nz_sel = filter(nz, Name %in% c("Northland", "Auckland"))
plot(nz_sel)

nz_elev_sel = crop(nz_elev, nz_sel)
nz_elev_sel2 = mask(nz_elev_sel, nz_sel)

library(tmap)
tm_shape(nz_elev_sel2) + 
  tm_raster(style = "cont") +
  tm_shape(nz_sel) +
  tm_borders()

#' 
#' 
