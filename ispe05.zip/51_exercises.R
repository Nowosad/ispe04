#' 
#' 1. Run the code `zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))` to read the borders of Zion National Park into R.
#' Calculate a buffer of 10 kilometers around Zion National Park.
#' What is the cumulative area of the 10 kilometers belt outside of Zion National Park?
#' (Note: do not count the area inside of the park.)
#' 2. Select objects for the year 2020 only from `urban_agglomerations`.
#' Clip the points representing major urban areas in Asia.
#' How this can be achieved using a different approach?
#' 3. Run the code `nz_study_area = st_as_sfc(st_bbox(c(xmin = 1400000, xmax = 1600000, ymin = 5000000, ymax = 5300000), crs = 2193))`.
#' It produces borders of a study area.
#' Use these borders to clip the `nz` object.
#' Visualize the results.
#' 4. Select "France" from the `world` object. 
#' Create a map of Mainland France (https://en.wikipedia.org/wiki/Metropolitan_France).
#' (Note: use `st_cast()`.)
