#' 
#' 1. Select Australia from the `world` dataset. 
#' Rasterize it to a resolution of 10 km.
#' Tests and compare different arguments, e.g., `fun` and `cover`.
#' 2. Change the `nz_elev` resolution to 8 kilometers.
#' Reclassify the values into three groups: below 300 meters, between 300 and 1000 meters, and above 1000 meters.
#' Vectorize and visualize the results.
