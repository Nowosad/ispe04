library(sf)
library(spData)
library(terra)
library(dplyr)
cho_proj = st_transform(cycle_hire_osm, "EPSG:27700")
raster_template = rast(ext(cho_proj), 
                       resolution = 1000,
                       crs = crs(cho_proj))

ch_raster1 = rasterize(vect(cho_proj), raster_template, field = 1)



ch_raster2 = rasterize(vect(cho_proj), raster_template, fun = length)



cho_proj2 = filter(cho_proj, !is.na(capacity))
ch_raster3 = rasterize(vect(cho_proj2), raster_template, field = "capacity", 
                       fun = sum, na.rm = TRUE)



world_moll = st_transform(world, crs = "+proj=moll")
raster_template2 = rast(ext(world_moll), 
                         resolution = 100000,
                         crs = crs(world_moll))

w_raster1 = rasterize(vect(world_moll), raster_template2, field = "name_long")



library(terra)
grain = rast(grain)
grain_poly = as.polygons(grain)
grain_poly_sf = st_as_sf(grain_poly)



srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm_c = as.contour(srtm)
srtm_csf = st_as_sf(srtm_c)
