library(sf)
library(spData)
library(tmap)
seine_cen = st_centroid(seine)
nz_cen = st_centroid(nz)
seine_pos = st_point_on_surface(seine)
nz_pos = st_point_on_surface(nz)



seine_buff_5km = st_buffer(seine, dist = 5000)
seine_buff_50km = st_buffer(seine, dist = 50000)



otago = nz %>% dplyr::filter(Name == "Otago")
nz_height_otago = st_intersection(nz_height, otago)
nz_height_otago



world
world_union = st_union(world)



st_union(seine_buff_50km)



multilinestring_list = list(matrix(c(1, 4, 5, 3), ncol = 2), 
                            matrix(c(4, 4, 4, 1), ncol = 2),
                            matrix(c(2, 4, 2, 2), ncol = 2))
multilinestring = st_multilinestring((multilinestring_list))
multilinestring_sf = st_sf(geom = st_sfc(multilinestring))
multilinestring_sf

linestring_sf2 = st_cast(multilinestring_sf, "LINESTRING")
linestring_sf2

linestring_sf2$length = st_length(linestring_sf2)

# points_sf = st_cast(linestring_sf2, "POINT")
multipoint_sf = st_cast(linestring_sf2, "MULTIPOINT")

multipoint_sf2 = multipoint_sf %>% 
  dplyr::mutate(id = 1) %>% 
  dplyr::group_by(id) %>% 
  dplyr::summarise()

polygon_sf = st_cast(multipoint_sf2, "POLYGON")
st_area(polygon_sf)
