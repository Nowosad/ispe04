#' 
#' 1. Select Australia from the `world` dataset. 
#' Rasterize it to a resolution of 10 km.
#' Tests and compare different arguments, e.g., `fun` and `getCover`.
#' 
## ----------------------------------------------------------------------
library(sf)
library(terra)
library(spData)

australia = world %>% 
  filter(name_long == "Australia")

plot(st_geometry(australia))

australia8059 = st_transform(australia, "EPSG:8059")

plot(st_geometry(australia8059))

raster_template = rast(ext(australia8059), 
                         resolution = 10000,
                         crs = crs(australia8059))

australia_r1 = rasterize(vect(australia8059), raster_template)
plot(australia_r1)

australia_r2 = rasterize(vect(australia8059), raster_template, cover = TRUE)
plot(australia_r2)

#' 
#' 2. Change the `nz_elev` resolution to 8 kilometers.
#' Reclassify the values into three groups: below 300 meters, between 300 and 1000 meters, and above 1000 meters.
#' Vectorize and visualize the results.
#' 
## ----------------------------------------------------------------------
library(spDataLarge)
nz_elev = rast(nz_elev)

raster_template_nz = rast(ext(nz_elev), 
                         resolution = 8000,
                         crs = crs(nz_elev))

nz_elev2 = resample(nz_elev, raster_template_nz)

rcl = matrix(c(-9999, 300, 1,
               300, 1000, 2,
               1000, 9999, 3),
             ncol = 3, byrow = TRUE)

nz_elev3 = classify(nz_elev2, rcl)
plot(nz_elev3)

nz_elev_poly = as.polygons(nz_elev3) %>% 
  st_as_sf()

plot(nz_elev_poly)

#' 
