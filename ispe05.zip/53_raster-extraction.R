library(terra)
library(dplyr)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))

study_area = rast(
  ncol = 101,
  nrow = 101,
  xmin = -113.0737,
  xmax = -112.9896,
  ymin = 37.26292,
  ymax = 37.34708,
  vals = 1
)



extract(srtm, ext(study_area))

srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
data("zion_points", package = "spDataLarge")



zion_extract = terra::extract(srtm, vect(zion_points))
zion_points$elevation = zion_extract$srtm
zion_points

zion_transect = cbind(c(-113.2, -112.9), c(37.45, 37.2)) %>%
  st_linestring() %>% 
  st_sfc(crs = crs(srtm)) %>% 
  st_sf()



transect = terra::extract(srtm, vect(zion_transect), 
                          touches = TRUE, cells = TRUE)
transect

transect_coords = xyFromCell(srtm, transect$cell)
pair_dist = geosphere::distGeo(transect_coords)[-nrow(transect_coords)]
transect$dist = c(0, cumsum(pair_dist)) 

zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))
zion = st_transform(zion, crs(srtm))
zion_srtm_values = terra::extract(srtm, vect(zion))



zion_srtm_values = terra::extract(srtm, vect(zion))

zion_srtm_values %>% 
  group_by(ID) %>% 
  summarize(across(srtm, list(min = min, mean = mean, max = max)))

zion_srtm_values2 = terra::extract(srtm, vect(zion), exact = TRUE)

zion_srtm_values2 %>% 
  group_by(ID) %>% 
  summarize(across(srtm, list(min = min, mean = mean, max = max)))

nlcd = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
zion_utm = st_transform(zion, crs = crs(nlcd))
zion_nlcd = terra::extract(nlcd, vect(zion_utm), factors = TRUE, exact = TRUE) 

zion_nlcd %>% 
  group_by(nlcd2011) %>% 
  summarise(area = sum(fraction) * yres(nlcd) * xres(nlcd)) %>% 
  tidyr::pivot_wider(values_from = area, names_from = nlcd2011)
