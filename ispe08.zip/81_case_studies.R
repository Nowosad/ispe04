library(sf)
library(terra)
library(spDataLarge)
library(tmap)
library(ggplot2)
library(dplyr)
library(gstat)        # geostatistics
library(randomForest) # random forest

sample_points = read_sf("data/sample_points.gpkg")

sample_points

tm_shape(sample_points) +
  tm_symbols(col = "temp_avg",
             style = "cont") +
  tm_grid()

srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))

tm_shape(srtm) +
  tm_raster(style = "cont", palette = "-Spectral") +
  tm_grid()

zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))

tm_shape(zion) +
  tm_polygons() +
  tm_grid()

ggplot(sample_points, aes(temp_avg)) +
  geom_histogram()

sample_points %>% 
  arrange(temp_avg)

sample_points %>% 
  arrange(-temp_avg)

sample_points = sample_points %>% 
  filter(temp_avg > -10, temp_avg < 35)

ggplot(sample_points, aes(temp_avg)) +
  geom_histogram()

tm_shape(sample_points) +
  tm_symbols(col = "temp_avg", style = "cont") +
  tm_grid()

srtm2 = project(srtm, sample_points)
tm_srtm1 = tm_shape(srtm) +
  tm_raster(style = "cont", palette = "-Spectral") +
  tm_grid()
tm_srtm2 = tm_shape(srtm2) +
  tm_raster(style = "cont", palette = "-Spectral") +
  tm_grid()
tmap_arrange(tm_srtm1, tm_srtm2)

tm_shape(srtm2) +
  tm_raster(style = "cont", palette = "-Spectral") +
  tm_shape(zion) +
  tm_borders() +
  tm_shape(sample_points) +
  tm_symbols(col = "temp_avg") +
  tm_layout(legend.outside = TRUE)

# caret::createDataPartition()
# rsample::initial_split()
set.seed(2021-05-18)
sample = sample.int(n = nrow(sample_points), 
                    size = floor(0.75 * nrow(sample_points)),
                    replace = FALSE)
train = sample_points[sample, ]
test = sample_points[-sample, ]

train

test

library(gstat)
interpolate_gstat = function(model, x, crs, ...) {
	v = st_as_sf(x, coords=c("x", "y"), crs=crs)
	p = predict(model, v, ...)
	as.data.frame(p)[,1:2]
}

st_crs(train) = st_crs(srtm2)
gs_idw = gstat(
  formula = temp_avg ~ 1,
  locations = train,
  set = list(idp = 1)
)
inter_idw = interpolate(srtm2, gs_idw, debug.level=0, fun = interpolate_gstat,
                        crs = crs(srtm2), index=1)



tm_shape(inter_idw) +
  tm_raster(style = "cont")

semivar1 = variogram(temp_avg ~ 1, locations = train)
plot(semivar1)

model1 = fit.variogram(semivar1, vgm(model = "Exp", nugget = 1))
plot(semivar1, model1)

gs_krige1 = gstat(formula = temp_avg ~ 1,
                  locations = train,
                  model = model1)

inter_krige1 = interpolate(srtm2, gs_krige1, debug.level=0, fun = interpolate_gstat,
                        crs = crs(srtm2), index = 1)

tm_shape(inter_krige1) +
  tm_raster(style = "cont")

extract_srtm = extract(srtm2, vect(train))
train$srtm = extract_srtm$srtm

semivar2 = variogram(temp_avg ~ srtm, locations = train)
plot(semivar2)

model2 = fit.variogram(semivar2, vgm(model = "Sph", nugget = 1))
plot(semivar2, model2)

gs_krige2 = gstat(formula = temp_avg ~ srtm,
                  locations = train,
                  model = model2)

inter_krige2 = interpolate(srtm2, 
                           gs_krige2,
                           xyOnly = FALSE, fun = interpolate_gstat,
                        crs = crs(srtm2), index = 1)

tm_shape(inter_krige2) +
  tm_raster(style = "cont")

library(randomForest)
model_rf = randomForest(temp_avg ~ srtm, 
                        data = st_drop_geometry(train))
model_rf

inter_rf = terra::predict(srtm2, 
                           model = model_rf)

tm_shape(inter_rf) +
  tm_raster(style = "cont")

all_models = c(inter_idw, inter_krige1, inter_krige2, inter_rf)
names(all_models) = c("idw", "krige1", "krige2", "rf")

tm_shape(all_models) +
  tm_raster(style = "cont")



test_models = extract(all_models, vect(test))
test = dplyr::bind_cols(test, test_models)
test

rmse = function(observed, interpolated){
  sqrt(mean((observed - interpolated) ^ 2))
}

rmse_idw = rmse(test$temp_avg, test$idw)
rmse_krige1 = rmse(test$temp_avg, test$krige1)
rmse_krige2 = rmse(test$temp_avg, test$krige2)
rmse_rf = rmse(test$temp_avg, test$rf)

rmse_idw
rmse_krige1

rmse_krige2
rmse_rf

inter_krige1_zion = crop(inter_krige1, vect(zion))
inter_krige1_zion = mask(inter_krige1_zion, vect(zion))
tm_shape(inter_krige1_zion) +
  tm_raster(style = "cont",
           palette = "OrRd",
           title = "Temperature (°C)\n(2019-09-30)") +
  tm_shape(zion) +
  tm_borders(col = "black", lwd = 2) +
  tm_layout(legend.position = c("left", "center"),
            inner.margins = 0.03,
            frame = FALSE,
            main.title = "Zion National Park") +
  tm_scale_bar(position = c("left", "bottom")) +
  tm_compass(type = "4star",
             size = 6,
             position = c("right", "top")) +
  tm_credits("Jakub Nowosad, 2021",
             position = c("RIGHT", "BOTTOM"))
