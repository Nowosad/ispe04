#' 
## ----------------------------------------------------------------------
nz_elev = rast(nz_elev)

#' 
#' 1. Create two simplified scenarios for sea-level rise for New Zealand: (1) rise of 10 meters, and (2) rise of 100 meters. 
#' How much area is going to be flooded based on these scenarios?
#' 2. Reclassify the `nlcd` object into four classes: 1 for Water and Wetlands, 2 for Developed, 3 for Barren, and 4 for Forest, Shrubland, Herbaceous, and Cultivated.
#' (See https://www.mrlc.gov/data/legends/national-land-cover-database-2011-nlcd2011-legend).
#' 3. Write a function to calculate the soil-adjusted vegetation index (SAVI; https://en.wikipedia.org/wiki/Soil-adjusted_vegetation_index).
#' Calculate SAVI for the Landsat 8 images for the area of Zion National Park. 
#' 4. Calculate SAVI for the same data using the `spectralIndices()` function from the [**RStoolbox**](https://bleutner.github.io/RStoolbox/rstbx-docu/index.html) package. 
#' Compare both results. 
#' Are they identical?
#' 5. Calculate mean focal values for the SAVI raster using a 3x3 and 9x9 moving window. 
#' When can the focal calculations be useful?
#' 6. Run the following code before doing this exercise: `srtm2 = projectRaster(srtm, nlcd)`.
#' Calculate a minimum, average, and maximum value of elevation from `srtm2` for each level in the `nlcd` dataset.
#' 7. Change each value from the `nlcd` dataset into the average elevation value for each level.
#' <!-- 8. Download the elevation data for each country of the British Isles' region (hint: `getData('ISO3')` can be useful). -->
#' Merge the downloaded data and create an elevation map of the British Isles' region.
