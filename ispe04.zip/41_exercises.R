#' 1. Select regions which contain points from `nz_height`.
#' 2. Which regions border with the Waikato region?
#' 3. How many points from `nz_height` are within 1000 meters from the Canterbury region, but are not in that region? 
#' Can you think of more than one solution to this problem?
#' 4. Additional: how many points from `nz_height` are located in each region?
#' 5. Select only those countries from `world`, which cities were never on the major urban areas list (`urban_agglomerations`).
#' 6. Load the `rivers` dataset from the **tmap** package using `data("rivers", package = "tmap")`.
#' Using the `world` object, calculate which country has the largest number of rivers in its borders.
#' Note: visit the `st_join()` function's help page (`?st_join`). 
