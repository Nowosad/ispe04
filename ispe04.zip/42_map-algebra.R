library(terra)
library(spDataLarge)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))

srtm2 = srtm + 1000

srtm3 = srtm - global(srtm, min)[[1]]

srtm4 = srtm - global(srtm, median)[[1]]



rcl = matrix(c(0, 1500, 1, 1500, 2000, 2, 2000, 9999, 3),
             ncol = 3, byrow = TRUE)
rcl

srtm_recl = classify(srtm, rcl = rcl)



landsat_path = system.file("raster/landsat.tif", package = "spDataLarge")
landsat = rast(landsat_path)

ndvi_fun = function(nir, red){
  (nir - red) / (nir + red)
}
ndvi = lapp(landsat[[c(4, 3)]], fun = ndvi_fun)



srtm_focal = focal(srtm, 
                   w = matrix(1, nrow = 3, ncol = 3), 
                   fun = var)





elev_by_grain = zonal(elev, grain, fun = "mean")
elev_by_grain

global(srtm, fun = "mean")
global(srtm, fun = "sd")













x = rast(xmin = -110, xmax = -50, ymin = 40, ymax = 70, ncols = 60, nrows = 30)
y = rast(xmin = -80, xmax = -20, ymax = 60, ymin = 30)
res(y) = res(x)
values(x) = 1:ncell(x)
values(y) = 1:ncell(y)



xy1 = merge(x, y)



xy2 = mosaic(x, y)



srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
nlcd = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))

c(srtm, nlcd)

crs(srtm, describe = TRUE)
crs(nlcd, describe = TRUE)

bbox(srtm)
bbox(nlcd)

res(srtm)
res(nlcd)

srtm2 = project(srtm, nlcd, method = "bilinear")

crs(srtm2, describe = TRUE)
crs(nlcd, describe = TRUE)

bbox(srtm2)
bbox(nlcd)

res(srtm2)
res(nlcd)

c(srtm2, nlcd)




nz_elev = rast(nz_elev)
