#' 
#' 1. Calculate the length of the New Zealand coastline using the `nz` object.
#' 
## ----------------------------------------------------------------------
library(sf)
library(spData)

nz2 = st_union(nz)
nz_lines = st_cast(nz2, "MULTILINESTRING")
st_length(nz_lines)

#' 
#' 2. Simplify the New Zealand coastline data using the `dTolerance` argument of 5000. 
#' Calculate the length of the New Zealand coastline using the newly created object.
#' Are the results different? <!--https://en.wikipedia.org/wiki/Coastline_paradox-->
#' 
## ----------------------------------------------------------------------
nz_lines2 = st_simplify(nz_lines, dTolerance = 5000)
st_length(nz_lines2)

#' 
#' 3. Calculate an average population density on the world and the continent level.
#' How can it be done? 
#' 
## ----------------------------------------------------------------------
library(sf)
library(spData)
library(dplyr)
world_pop_dens = world %>% 
  mutate(pop_dens = pop/area_km2)

world_pop_dens_g = world_pop_dens %>% 
  summarise(dens_avg = mean(pop_dens, na.rm = TRUE))

world_pop_dens_c = world_pop_dens %>% 
  group_by(continent) %>% 
  summarize(dens_avg = mean(pop_dens, na.rm = TRUE))

#' 
#' 4. Create a map with three panels representing a population density on a (1) country, (2) continent, and (3) world level.
#' 
## ----------------------------------------------------------------------
tm1 = tm_shape(world_pop_dens) + tm_polygons("pop_dens")
tm2 = tm_shape(world_pop_dens_c) + tm_polygons("dens_avg")
tm3 = tm_shape(world_pop_dens_g) + tm_polygons("dens_avg")

tmap_arrange(tm1, tm2, tm3)

#' 
#' 5. Create a map of New Zealand's regions with New Zealand borders represented by a thick line.
#' How can this be achieved?
#' 
## ----------------------------------------------------------------------
library(spData)
library(dplyr)
nz_agg = nz %>% 
  summarize()

library(tmap)
tm_shape(nz) +
  tm_polygons() +
  tm_shape(nz_agg) +
  tm_borders(lwd = 4, col = "red")

#' 
#' 6. Create a new variable `pop_change` in the `us_states` dataset. 
#' This variable should represent changes between the population in 2010 and 2015.
#' Aggregate the US states into two groups: (1) with population growth, (2) with a population loss.
#' Visualize the results.
#' 
## ----------------------------------------------------------------------
us_states2 = us_states %>% 
  mutate(pop_change = total_pop_15 - total_pop_10) %>% 
  mutate(pop_change2 = pop_change > 0) %>% 
  group_by(pop_change2) %>% 
  summarize()

tm_shape(us_states2) +
  tm_polygons(col = "pop_change2", lwd = 7) +
  tm_shape(us_states) +
  tm_borders()

#' 
#' 7. The `nz_elev` dataset (`nz_elev = rast(nz_elev)`)has a resolution of 1000 meters. 
#' Change it to a resolution of 10 kilometers. 
#' Create two maps comparing the results.
#' When the map with a lower resolution could we useful?
#' 
## ----------------------------------------------------------------------
data(nz_elev, package = "spDataLarge")
nz_elev = rast(nz_elev)
nz_elev2 = aggregate(nz_elev, fact = 10)

my_breaks = c(0, 1000, 2000, 3000, 4000, 5000)

tm1 = tm_shape(nz_elev) + tm_raster(breaks = my_breaks)
tm2 = tm_shape(nz_elev2) + tm_raster(breaks = my_breaks)
tmap_arrange(tm1, tm2)

#' 
