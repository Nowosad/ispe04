#' 1. Load the `rivers` dataset from the **tmap** package using `data("rivers", package = "tmap")`.
#' Calculate lengths of rivers stored in this object in kilometers.
#' (Hint: you need to aggregate the data.)
#' 2. Calculate the area of each region in the `nz` object. 
#' Compare it with the `Land_area` variable.
#' For which region the values are the most and the least different?
#' 3. What is the surface area of the areas above 2500 meters a.s.l. in the `srtm` dataset (`srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))`)?
