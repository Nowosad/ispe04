#' 1. Calculate the length of the New Zealand coastline using the `nz` object.
#' 2. Simplify the New Zealand coastline data using the `dTolerance` argument of 5000. 
#' Calculate the length of the New Zealand coastline using the newly created object.
#' Are the results different? <!--https://en.wikipedia.org/wiki/Coastline_paradox-->
#' 3. Calculate an average population density on the world and the continent level.
#' How can it be done? 
#' 4. Create a map with three panels representing a population density on a (1) country, (2) continent, and (3) world level.
#' 5. Create a map of New Zealand's regions with New Zealand borders represented by a thick line.
#' How can this be achieved?
#' 6. Create a new variable `pop_change` in the `us_states` dataset. 
#' This variable should represent changes between the population in 2010 and 2015.
#' Aggregate the US states into two groups: (1) with population growth, (2) with a population loss.
#' Visualize the results.
#' 7. The `nz_elev` dataset has a resolution of 1000 meters. 
#' Change it to a resolution of 10 kilometers. 
#' Create two maps comparing the results.
#' When the map with a lower resolution could we useful?
