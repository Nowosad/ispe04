library(sf)
library(spData)
seine_simp = st_simplify(seine, dTolerance = 5000) # 5000 m



library(rmapshaper)
us_states2163 = st_transform(us_states, 2163)
us_states2163$AREA = as.numeric(us_states2163$AREA)
us_states_simp = ms_simplify(us_states2163, keep = 0.01, keep_shapes = TRUE)



library(sf)
library(dplyr)
library(spData)
world_sum = world %>% 
  summarize(pop = sum(pop, na.rm = TRUE), n = n())

world_agg = world %>%
  group_by(continent) %>%
  summarize(pop = sum(pop, na.rm = TRUE))



library(terra)
library(spDataLarge)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm_agg = aggregate(srtm, fact = 10, fun = mean)
res(srtm)
res(srtm_agg)



srtm_disagg = disaggregate(srtm_agg, fact = 10, method = "bilinear")



srtm

new_srtm = srtm
res(new_srtm) = 0.001
new_srtm

srtm2 = resample(srtm, new_srtm, method = "bilinear") # method!
srtm2
