#' 
#' 1. Create two simplified scenarios for sea-level rise for New Zealand: (1) rise of 10 meters, and (2) rise of 100 meters. 
#' How much area is going to be flooded based on these scenarios?
#' 
## ----------------------------------------------------------------------
library(spDataLarge)
library(tmap)
library(terra)
nz_elev = rast(nz_elev)

nz_now = tm_shape(nz_elev) +
  tm_raster(style = "cont",
            palette = "-RdYlGn",
            midpoint = 0) +
  tm_layout(bg.color = "lightblue")

nz_elev2 = nz_elev - 10
nz_elev2[nz_elev2 < 0] = NA

nz_plus10 = tm_shape(nz_elev2) +
  tm_raster(style = "cont",
            palette = "-RdYlGn",
            midpoint = 0) +
  tm_layout(bg.color = "lightblue")

nz_elev3 = nz_elev - 100
nz_elev3[nz_elev3 < 0] = NA

nz_plus100 = tm_shape(nz_elev3) +
  tm_raster(style = "cont",
            palette = "-RdYlGn",
            midpoint = 0) +
  tm_layout(bg.color = "lightblue")

tmap_arrange(nz_now, nz_plus10, nz_plus100)

# areas
nz_elev_vals1 = values(nz_elev)[, 1]
nz_elev_vals2 = values(nz_elev2)[, 1]
nz_elev_vals3 = values(nz_elev3)[, 1]

cell_diff_plus10 = sum(is.na(nz_elev_vals2)) - sum(is.na(nz_elev_vals1))

(cell_diff_plus10 * xres(nz_elev) * yres(nz_elev)) / 1000000 # change in km2

cell_diff_plus100 = sum(is.na(nz_elev_vals3)) - sum(is.na(nz_elev_vals1))

(cell_diff_plus100 * xres(nz_elev) * yres(nz_elev)) / 1000000 # change in km2

#' 
#' 2. Reclassify the `nlcd` object into four classes: 1 for Water and Wetlands, 2 for Developed, 3 for Barren, and 4 for Forest, Shrubland, Herbaceous, and Cultivated.
#' (See https://www.mrlc.gov/data/legends/national-land-cover-database-2011-nlcd2011-legend ).
#' 
## ----------------------------------------------------------------------
library(spDataLarge)
nlcd = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))

rcl = matrix(c(11, 12, 1,
               21, 24, 2,
               31, 31, 3,
               41, 82, 4,
               90, 95, 1),
             ncol = 3, byrow = TRUE)
nlcd_recl = classify(nlcd, rcl = rcl, include.lowest = TRUE, right = NA)
plot(nlcd_recl)

#' 
#' 3. Write a function to calculate the soil-adjusted vegetation index (SAVI; https://en.wikipedia.org/wiki/Soil-adjusted_vegetation_index ).
#' Calculate SAVI for the Landsat 8 images for the area of Zion National Park. 
#' 
## ----------------------------------------------------------------------
landsat_path = system.file("raster/landsat.tif", package = "spDataLarge")
landsat = rast(landsat_path)

savi_fun = function(nir, red, L = 0.5){
  ((1 + L) * (nir - red)) / (nir + red + L)
}
savi = lapp(landsat[[c(4, 3)]], fun = savi_fun)

plot(savi)

#' 
#' 4. Calculate SAVI for the same data using the `spectralIndices()` function from the [**RStoolbox**](https://bleutner.github.io/RStoolbox/rstbx-docu/index.html) package. 
#' Compare both results. 
#' Are they identical?
#' 
## ----------------------------------------------------------------------
library(RStoolbox)
savi2 = spectralIndices(raster::stack(landsat), red = 3, nir = 4, indices = "SAVI")
savi2 = rast(savi2)
savi_diff = savi - savi2
savi_diff

#' 
#' 5. Calculate mean focal values for the SAVI raster using a 3x3 and 9x9 moving window. 
#' When can the focal calculations be useful?
#' 
## ----------------------------------------------------------------------
savi_focal3 = focal(savi, 
                    w = matrix(1, nrow = 3, ncol = 3), 
                    fun = mean)

savi_focal10 = focal(savi, 
                     w = matrix(1, nrow = 9, ncol = 9), 
                     fun = mean)

tm_shape(c(savi, savi_focal3, savi_focal10)) +
  tm_raster(style = "cont")

#' 
#' 6. Run the following code before doing this exercise: `srtm2 = project(srtm, nlcd)`.
#' Calculate a minimum, average, and maximum value of elevation from `srtm2` for each level in the `nlcd` dataset.
#' 
## ----------------------------------------------------------------------
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm2 = project(srtm, nlcd)
zonal(srtm2, nlcd, fun = "min", na.rm = TRUE)
zonal(srtm2, nlcd, fun = "mean", na.rm = TRUE)
zonal(srtm2, nlcd, fun = "max", na.rm = TRUE)

#' 
#' 7. Change each value from the `nlcd` dataset into the average elevation value for each level.
#' 
## ----------------------------------------------------------------------
rcl2 = zonal(srtm2, nlcd, fun = "mean", na.rm = TRUE)
nlcd_recl = classify(nlcd, rcl = rcl2)
plot(nlcd_recl)

