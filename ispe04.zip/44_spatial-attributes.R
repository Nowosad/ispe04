library(sf)
library(dplyr)
library(spData)
library(units)

plot(seine)

st_length(seine)

seine$length = st_length(seine)
seine$length = set_units(st_length(seine), "ft")
seine$length = as.numeric(st_length(seine))

plot(nz["Name"])

st_length(nz)

nz2 = nz %>% st_cast("MULTILINESTRING")
st_length(nz2)

nz$perimeter = st_length(nz2)

plot(nz["Name"])

st_area(nz)

nz$area = set_units(st_area(nz), "km2")
nz$area = as.numeric(st_area(nz))

library(terra)
data(nz_elev, package = "spDataLarge")
nz_elev = rast(nz_elev)
nz_elev

nz_elev_values = values(nz_elev)

length(na.omit(nz_elev_values))

length(na.omit(nz_elev_values)) * xres(nz_elev) * yres(nz_elev) 

length(na.omit(nz_elev_values)) * xres(nz_elev) * yres(nz_elev) / 1000000

nlcd = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
nlcd

freq_nlcd = freq(nlcd)
freq_nlcd = as.data.frame(freq_nlcd)
freq_nlcd$area_m2 = freq_nlcd$count * xres(nlcd) * yres(nlcd)
freq_nlcd$area_km2 = freq_nlcd$area_m2 / 1000000
freq_nlcd
