#' 
#' Run the code:
#' 
## ----------------------------------------------------------------------
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))

#' 
#' 1. Extract elevation values (`srtm`) for the points from the `zion_points` object.
#' Save the result: (1) in the GeoPackage format, (2) in the ESRI Shapefile format, (3) as a text file.
#' The text file should have three columns with (1) elevation value, (2) latitude, (3) longitude. 
#' 
## ----------------------------------------------------------------------
library(terra)
library(sf)
library(spData)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))

srtm_vals = extract(srtm, vect(zion_points))
zion_points$srtm = srtm_vals$srtm

write_sf(zion_points, "zion_points_srtm.gpkg")
write_sf(zion_points, "zion_points_srtm.shp")

zion_points_coords = as.data.frame(st_coordinates(zion_points))
zion_points2 = st_drop_geometry(zion_points)
zion_points2 = dplyr::bind_cols(zion_points2, zion_points_coords) 
write.csv(zion_points2, "zion_points_srtm.csv")

#' 
#' 2. Read the text file back to R as an sf object.
#' 
## ----------------------------------------------------------------------
zion_points3 = read.csv("zion_points_srtm.csv")
zion_points3 = st_as_sf(zion_points2, coords = c("X", "Y"))
zion_points3

#' 
#' 3. Extract land cover categories (`nlcd` ) for the points from this new object.
#' Overwrite the three previously created files with new ones with additional information.
#' 
## ----------------------------------------------------------------------
library(spDataLarge)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
nlcd2 = project(nlcd, srtm, method = "near")

nlcd_vals = extract(nlcd2, vect(zion_points3))
zion_points3$nlcd = nlcd_vals$nlcd2011

write_sf(zion_points3, "zion_points_srtm.gpkg")
write_sf(zion_points3, "zion_points_srtm.shp")

zion_points3 = dplyr::bind_cols(zion_points3, zion_points_coords) 
write.csv(zion_points3, "zion_points_srtm.csv")

#' 
#' 4. Write the `srtm` object as a GeoTIFF file using: (1) an "INT1U" data type, (2) an "FLT4S" data type, (3) an "LZW" compression.
#' Compare the size of the output files.
#' Read the new files into R and visualize them.
#' Can you see any differences between them?
#' 
## ----------------------------------------------------------------------
writeRaster(srtm, "srtm1.tif", datatyle = "INT1U")
writeRaster(srtm, "srtm2.tif", datatyle = "FLT4S")
writeRaster(srtm, "srtm3.tif", gdal = "COMPRESS=LZW")

srtm1 = raster("srtm1.tif")
srtm2 = raster("srtm2.tif")
srtm3 = raster("srtm3.tif")

#' 
