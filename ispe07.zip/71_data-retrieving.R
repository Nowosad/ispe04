library(curl)
library(sf)
curl_download(url = "https://irma.nps.gov/DataStore/DownloadFile/658912",
              destfile = "nps_boundary.zip")
unzip("nps_boundary.zip")
usa_parks = read_sf(dsn = "nps_boundary.shp")

curl_download(url = "https://irma.nps.gov/DataStore/DownloadFile/658912",
              destfile = "nps_boundary.zip")
dir.create("data")
unzip(zipfile = "nps_boundary.zip", exdir = "data")
usa_parks = read_sf("data/nps_boundary.shp")
file.remove("nps_boundary.zip")



url = "https://opendata.arcgis.com/datasets/d333c7529754444894e2d7f5044d1bbf_0.kml?outSR=%7B%22latestWkid%22%3A27700%2C%22wkid%22%3A27700%7D"
dir.create("data")
curl_download(url = url,
              destfile = "data/np.kml")
np = read_sf("data/np.kml")



url = "https://www.naturalearthdata.com/http//www.naturalearthdata.com/download/110m/physical/ne_110m_coastline.zip"
dir.create("data")
curl_download(url = url,
              destfile = "ne_110m_coastline.zip")
unzip(zipfile = "ne_110m_coastline.zip", exdir = "data")
coastline = read_sf("data/ne_110m_coastline.shp")
file.remove("ne_110m_coastline.zip")
