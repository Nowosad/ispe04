#' 
#' 1. Download the US national parks data from https://irma.nps.gov/DataStore/.
#' Select only the National Parks from the contiguous United States and visualize them.
#' 2. Visit some of the sites mentioned on the third slide. 
#' Try to download one selected dataset from R.
#' 3. Skim through the list at http://freegisdata.rtwilson.com/. 
#' Are there any websites with data useful to your daily work? 
#' Check if it is possible to download the data from these websites automatically?
