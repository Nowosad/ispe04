library(sf)
library(spData)
nz_height

write_sf(obj = nz_height, dsn = "nz_height.gpkg")

write_sf(obj = nz_height, dsn = "nz_height.gpkg")

write_sf(obj = nz_height, dsn = "nz_height.gpkg", layer = "new_layer")

write_sf(obj = nz_height, dsn = "nz_height.csv", layer_options = "GEOMETRY=AS_XY")

nz_height_coords = as.data.frame(st_coordinates(nz_height))
nz_height2 = dplyr::bind_cols(nz_height, nz_height_coords) %>%
  st_drop_geometry()
write.csv(nz_height2, "nz_height.csv")

library(terra)
library(spDataLarge)
nlcd = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
landsat_path = system.file("raster/landsat.tif", package = "spDataLarge")
landsat = rast(landsat_path)

writeRaster(nlcd, filename = "nlcd1.tif", gdal = c("COMPRESS=NONE"))
writeRaster(nlcd, filename = "nlcd2.tif", datatype = "INT1U")
writeRaster(nlcd, filename = "nlcd3.tif", gdal = c("COMPRESS=DEFLATE"))
writeRaster(nlcd, filename = "nlcd4.tif", datatype = "INT1U",
            gdal = c("COMPRESS=DEFLATE"))

writeRaster(landsat, filename = "landsat1.tif")
writeRaster(landsat, filename = "landsat2.tif",
            names = c("band2", "band3", "band4", "band5"))


srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
