#' 
#' 1. Create a map of Scotland. 
#' Keep the England and Nothern Ireland borders on the map to provide a context.
#' 
## ----------------------------------------------------------------------
library(sf)
library(rnaturalearth)
library(tmap)
uk3 = ne_countries(scale = 10, 
                   country = "United Kingdom",
                   type = "map_units",
                   returnclass = "sf") 
scotland2 = uk3 %>% 
  dplyr::filter(subunit == "Scotland")

tm_shape(uk3) +
  tm_borders() +
  tm_shape(scotland2, is.master = TRUE) +
  tm_polygons()

#' 
#' 2. Run the code `course_location = st_sfc(st_point(c(-4.268, 55.854)), crs = 4326)`to create a point representing the (non-remote) location of this course.
#' Create a 1-kilometer buffer around this point and download a road network for this area. 
#' Visualize the results.
#' (Hint: The https://wiki.openstreetmap.org/wiki/Map_Features website could be useful here.)
#' 
## ----------------------------------------------------------------------
library(osmdata)
course_location = st_sfc(st_point(c(-4.268, 55.854)), crs = 4326)
course_location2 = st_transform(course_location, 27700)
course_location3 = st_buffer(course_location2, 1000)
course_location4 = st_transform(course_location3, 4326)

roads = opq(bbox = course_location4) %>% 
  add_osm_feature(key = "highway") %>% 
  osmdata_sf()
roads

tm_shape(course_location4) +
  tm_polygons() +
  tm_shape(roads$osm_lines) +
  tm_lines()

#' 
#' 3. Get the primary road network data for the Zion National Park area.
#' Extract the elevation values along the road.
#' 
## ----------------------------------------------------------------------
library(spData)
library(terra)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))

roads_zion = opq(bbox = st_bbox(srtm)) %>% 
  add_osm_feature(key = "highway", value = "motorway") %>% 
  osmdata_sf()
zion_main_road = st_as_sf(st_union(roads_zion$osm_lines))

transect = extract(srtm, vect(zion_main_road))
transect

#' 
#' 4. Download the elevation data for the Zion National Park.  
#' Compare the result with the `srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))` object. 
#' Are there any differences between these two objects?
#' 
## ----------------------------------------------------------------------
library(terra)
library(elevatr)
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"))
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
zion_elev_alt = get_elev_raster(zion, z = 8, clip = "bbox")

plot(zion_elev_alt)
plot(srtm)

#' 
#' 5. Search for some more R data packages?
#' Are there any data packages potentially useful to your daily work? 
#' Check if you can download the data using these packages?
#' 
