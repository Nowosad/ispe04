library(spData)
library(sf)

st_crs(world)

st_crs(world)$proj4string
st_crs(world)$epsg
st_crs(world)$wkt

library(spData)
library(terra)
elev = rast(elev)

crs(elev, describe = TRUE)
crs(elev)

st_crs(elev)

london_geo = data.frame(lon = -0.1, lat = 51.5) %>% 
  st_as_sf(coords = c("lon", "lat"), crs = "EPSG:4326")

# an EPSG code of 27700: the British National Grid
london_proj = st_transform(london_geo, crs = "EPSG:27700")





london_geo_buff = st_buffer(london_geo, dist = 1)
london_proj_buff = st_buffer(london_proj, 111320)






library(spDataLarge)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)
