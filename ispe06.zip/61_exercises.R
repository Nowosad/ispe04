#' 
#' Run the code below:
#' 
## ----------------------------------------------------------------------
library(spDataLarge)
srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)

#' 
#' 1. Check the CRS of the `srtm` and `zion` objects.
#' What are the maps units of these objects? 
#' What kind of information can be found in the CRS descriptions?
#' 2. Run the code `plot(srtm, axes = TRUE); plot(st_geometry(zion), add = TRUE)`. 
#' It supposes to create a map of `srtm` with a border of `zion` on the top. 
#' Why can we not see the borders in the resulting map?
#' 3. Try to create a map of `srtm` with a border of `zion` on the top using the **tmap** package.
#' Can you see both layers now?
#' Why is it different from a base `plot()` function?
#' 4. Think about the data you regularly use. 
#' What is the CRS of these data? 
#' Is it Geographic CRS or Projected CRS?
#' What are the properties of the CRS you use?
#' 5. Try to think about the consequences of using different map projection in your own work.
#' What are the possible problems that can occur?
