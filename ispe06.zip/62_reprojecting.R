library(sf)
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)
data(zion_points, package = "spDataLarge")





zion_points2a = st_transform(zion_points,
                             crs = "EPSG:26912")

zion_points3 = st_transform(zion_points, st_crs(zion))
zion_points3





library(terra)
cat_raster = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
crs(cat_raster, describe = TRUE)

unique(cat_raster)



wgs84 = "EPSG:4326"
cat_raster_wgs84 = project(cat_raster, wgs84, method = "near")





con_raster = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
crs(con_raster, describe = TRUE)

hist(con_raster)



equalarea = 'PROJCS["ProjWiz_Custom_Albers",
 GEOGCS["GCS_WGS_1984",
  DATUM["D_WGS_1984",
   SPHEROID["WGS_1984",6378137.0,298.257223563]],
  PRIMEM["Greenwich",0.0],
  UNIT["Degree",0.0174532925199433]],
 PROJECTION["Albers"],
 PARAMETER["False_Easting",0.0],
 PARAMETER["False_Northing",0.0],
 PARAMETER["Central_Meridian",-113.04],
 PARAMETER["Standard_Parallel_1",32.32],
 PARAMETER["Standard_Parallel_2",42.32],
 PARAMETER["Latitude_Of_Origin",37.32],
 UNIT["Meter",1.0]]'
con_raster_ea = project(con_raster, equalarea, method = "bilinear")
crs(con_raster_ea, describe = TRUE)





srtm = rast(system.file("raster/srtm.tif", package = "spDataLarge"))
zion = read_sf(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)





zion2 = st_transform(zion, crs(srtm))





vector_filepath = system.file("vector/zion.gpkg", package = "spDataLarge")
new_vector = read_sf(vector_filepath)
st_crs(new_vector) # get CRS
new_vector = st_set_crs(new_vector, "EPSG:4326") # set CRS

raster_filepath = system.file("raster/srtm.tif", package = "spDataLarge")
new_raster = rast(raster_filepath)
crs(new_raster, describe = TRUE) # get CRS
crs(new_raster) = "EPSG:6341" # set CRS
