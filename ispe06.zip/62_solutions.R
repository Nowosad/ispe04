#' 1. Transform the `us_states` object into the USA Contiguous Albers Equal Area Conic CRS (https://spatialreference.org/ref/esri/usa-contiguous-albers-equal-area-conic/).
#' Create a visualization comparing this object before and after reprojecting.
#' 
## ----------------------------------------------------------------------
library(sf)
library(tmap)
library(spData)
tm1 = tm_shape(us_states) +
  tm_polygons() +
  tm_grid()

us_states2 = st_transform(us_states, "ESRI:102003")

tm2 = tm_shape(us_states2) +
  tm_polygons() +
  tm_grid()

tmap_arrange(tm1, tm2)

#' 
#' 2. Calculate states' areas before and after reprojecting. 
#' What is the average difference between the calculated states' areas?
#' What is the total difference between the calculated areas?
#' 
## ----------------------------------------------------------------------
library(dplyr)
a1 = st_area(us_states)
a2 = st_area(us_states2)

us_states2$diff = units::set_units(abs(a1 - a2), km2)

units::set_units(sum(a1 - a2), km2)

us_states2 %>%
  arrange(-diff)

#' 
#' 3. Additional: try to use the `gdalwarp` function from the **gdalUtils** package to reproject the `srtm.tif` file to the CRS of the `zion` object. 
#' (Note: a blog post at https://nowosad.github.io/post/lsm-bp1/ could be useful here.)
#' 
## ----------------------------------------------------------------------
library(terra)
library(gdalUtils)
nlcd_path = rast(system.file("raster/nlcd2011.tif", package = "spDataLarge"))
srtm_path = system.file("raster/srtm.tif", package = "spDataLarge")

gdalwarp(srcfile = srtm_path,
         dstfile = "data/new_srtm.tif",
         t_srs = crs(nlcd_path, proj4 = TRUE))

new_srtm = raster("data/new_srtm.tif")
plot(new_srtm)

#' 
#' 4. Select `"Canada"`, and `"Mexico"` from the `world` object. 
#' Add the results to the `us_states` object and visualize the results.
#' 
## ----------------------------------------------------------------------
library(dplyr)
canada_mexico = filter(world, name_long %in% c("Canada", "Mexico"))
canada_mexico2 = st_transform(canada_mexico, st_crs(us_states))

all = c(st_geometry(us_states), st_geometry(canada_mexico2))
plot(all)

