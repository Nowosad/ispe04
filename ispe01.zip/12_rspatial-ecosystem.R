# citation()
citation("tmap")





library(spData)
library(sp)
library(sf)
world_sp = as(world, Class = "Spatial")
# sp functions ...

world_sf = st_as_sf(world_sp)

# lsf.str("package:sf")
ls("package:sf")



library(spData)
library(sf)

world

plot(world)

file_path = system.file("shapes/world.gpkg", package = "spData")
file_path
# world = read_sf(file_path)

world = read_sf("/home/jn/R/x86_64-redhat-linux-gnu-library/4.0/spData/shapes/world.gpkg")

cycle_hire_path = system.file("misc/cycle_hire_xy.csv", package = "spData")
cycle_hire_txt = read.csv(cycle_hire_path)
head(cycle_hire_txt)

cycle_hire_xy = st_as_sf(cycle_hire_txt, coords = c("X", "Y"), crs = "EPSG:4326")
cycle_hire_xy

plot(cycle_hire_xy)

library(spData)
library(terra)

rast(elev)

plot(elev)

elev[]

raster_filepath = system.file("raster/srtm.tif", package = "spDataLarge")
new_raster = rast(raster_filepath)
new_raster

raster_filepath2 = system.file("raster/landsat.tif", package = "spDataLarge")
new_raster2 = rast(raster_filepath2)
plot(new_raster2)

plotRGB(new_raster2, r = 3, g = 2, b = 1, stretch = "lin")

my_raster = rast(nrows = 10, ncols = 20, 
                 xmin = 0, xmax = 20, ymin = -10, ymax = 0,
                 crs = "EPSG:4326",
                 vals = 1:200)
my_raster


plot(my_raster)

my_raster2 = rast(res = c(1, 1),
                   xmin = 0, xmax = 20, ymin = -10, ymax = 0,
                   crs = "EPSG:4326",
                   vals = 1:200)
my_raster2

plot(my_raster2)
